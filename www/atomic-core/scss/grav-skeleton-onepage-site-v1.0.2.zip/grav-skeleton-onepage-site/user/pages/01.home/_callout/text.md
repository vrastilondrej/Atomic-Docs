---
title: Homepage Callout
menu: Easy Content
image_align: right
---

## Content Unchained

No longer are you a _slave to your CMS_. Grav **empowers** you to create anything from a [simple one-page site](#), to a [beautiful blog](#), to a powerful and feature-rich [product site](#), to pretty much anything you can dream up!
