# v1.0.2
## 01/06/2016

1. [](#improved)
    * Moved dependencies to master branch

# v1.0.1
## 04/24/2015

1. [](#improved)
    * Grammar fixes

# v1.0.0
## 12/21/2014

1. [](#improved)
    * Updated with Antimatter Theme v1.2.6

# v0.9.10
## 12/12/2014

1. [](#new)
    * ChangeLog started...
