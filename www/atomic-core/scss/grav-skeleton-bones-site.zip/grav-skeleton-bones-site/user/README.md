# Grav Bones Skeleton Site

This skeleton install provides a full site setup with sample content for Grav using the [Bones](https://github.com/smartgravity/grav-theme-bones) theme.

Essentially, this replaces the `/user/` directory for a Grav install. You can download the repository, replace your `/user/` directory with it, then run `bin/grav install` from CLI to install all dependencies, or download the full zip package included with the release for a ready-to-go Grav install with everything included.
