<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Bones extends Theme
{

}
