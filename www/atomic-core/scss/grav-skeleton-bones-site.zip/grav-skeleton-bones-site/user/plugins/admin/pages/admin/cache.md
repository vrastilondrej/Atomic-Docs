---
title: Cache

access:
    admin.cache: true
    admin.super: true
---
