---
title: Reset password

form:
    fields:
        - name: username
          type: text
          placeholder: Username
          readonly: true
        - name: password
          type: password
          placeholder: Password
          autofocus: true
        - name: token
          type: hidden
---

