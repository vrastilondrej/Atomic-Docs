---
title: Backgrounds
styles: 'sg-spacer-xlarge sg-center sg-background-fixed'
---

## **Backgrounds**

`sg-background-fixed`
