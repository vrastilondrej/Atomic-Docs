---
title: Gallery
styles: 'center-title sg-center sg-color-dark-gray'
gallery:
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
    -
        image: arches.jpg
        title: Arches
        description: 'Summer 2015'
column_number: '4'
---

---
The modular gallery uses Featherlight, a lightbox popup plugin for Grav. You can find more inforation on the [Featherlight GitHub <i class="fa fa-github"></i> page](https://github.com/getgrav/grav-plugin-featherlight).

You can also choose the number of columns and the twig template will calculate the number of columns for smaller screensizes automatically. Your options are 2, 3, 4, 5, and 6.

---

