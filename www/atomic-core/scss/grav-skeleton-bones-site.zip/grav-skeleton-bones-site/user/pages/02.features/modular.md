---
title: Features
body_classes: modular
foundation_sticky_js: enabled
foundation_magellan_js: enabled
featherlight:
  enabled: true
  active: true
content:
  items: '@self.modular'
  order:
    dir: asc
    by: default
    custom:
      - _showcase
      - _in-page-navigation
      - _text
      - _gallery
      - _backgrounds
      - _buttons
      - _columns
      - _text-image-right
      - _row-image-left
---
