---
title: Footer
routable: false
visible: false
markdown:
    extra: true
---

Powered by: [Grav](http://getgrav.org/)  
Style framework: [Foundation 6](http://foundation.zurb.com/) by Zurb  
Color Palette from RocketTheme's [Xenon Template](http://www.rockettheme.com/joomla/templates/xenon)  
Skull icon by: [Go Media](https://arsenal.gomedia.us/shop/vectors/skulls-2-vector-pack/)  

**Glued and stapled together by:**  
[![SmartGravity - Website Engineering](smartgravity.png?cropResize=132,31){.logo}](http://www.smartgravity.com)  