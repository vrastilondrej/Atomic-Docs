---
title: Lists
styles: 'center-title sg-color-light-gray'
column_number: '2'
---

#### Unordered Lists

- List item with a much longer description or more content.
- List item
- List item
  - Nested list item
  - Nested list item
  - Nested list item
- List item
- List item
- List item

---

#### Ordered Lists

1. Cheese (essential)
2. Pepperoni
3. Bacon
   1. Normal bacon
      1. More bacon
      2. Even more bacon
   2. Canadian bacon
4. Mushrooms
5. Onions

