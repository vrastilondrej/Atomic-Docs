---
title: Typography
body_classes: modular
foundation_sticky_js: enabled
foundation_magellan_js: enabled
content:
    order:
        dir: asc
        by: default
        custom:
            - _showcase
            - _in-page-navigation
            - _basics
            - _headers
            - _blockquotes
            - _code
            - _tables
            - _lists
    items: '@self.modular'
---

