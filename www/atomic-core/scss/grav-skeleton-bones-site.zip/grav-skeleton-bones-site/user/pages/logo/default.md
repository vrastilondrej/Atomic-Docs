---
title: Logo
routable: false
visible: false
---

The site title is used for the type. 
This is the logo icon that should be a square image.