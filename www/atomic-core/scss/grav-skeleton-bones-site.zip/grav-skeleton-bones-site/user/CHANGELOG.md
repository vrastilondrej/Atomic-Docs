# v0.4.0
## 2/1/2016

1. [](#improved)
    * Updated to include new Bones v0.4.0 theme release
    * The new release uses Foundation v6.1.2

# v0.3.1
## 1/24/2016

1. [](#improved)
    * Updated to include new Bones v0.3.1 theme release
    * Better separated JS and CSS Assets
2. [](#bugfix)
    * Removed unnecessary Foundation index.html file
    * Fixed fallback styling for non-fontawesome mobilemenu icon

# v0.3.0
## 1/23/2016

1. [](#improved)
    * Updated to include new Bones v0.3.0 theme release
    * Removed Random Plugin from dependencies
    * Added Admin Plugin to dependencies

# v0.2.0
## 1/20/2016

1. [](#improved)
		* Updated to include new Bones v0.2.0 theme release
2. [](#bugfix)
    * Added correct default JS settings for Features and Typography pages
    * Added Featherlight settings to Features frontmatter to enable by default


# v0.1.0
## 1/19/2016

1. [](#new)
		* Initial Release
